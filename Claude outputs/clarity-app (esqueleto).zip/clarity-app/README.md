# Clarity — web app

Web app do projeto Clarity (CVPBT Grupo 13 / GPTSI Grupo 17, ISCTE): importa as notas do psicólogo, propõe resumos de sessão que o psicólogo valida e prepara um briefing antes de cada consulta.

> **Regra do projeto:** até existir a avaliação de impacto (RGPD), **só se usam dados fictícios**. Nenhuma nota real de pacientes entra nesta app, nem em desenvolvimento nem em pré-visualizações.

## Stack

| Camada | Tecnologia |
|---|---|
| Frontend | React + Vite + TypeScript, PWA (`vite-plugin-pwa`) |
| Alojamento | Vercel (plano gratuito), pré-visualização em cada pull request |
| Backend | Supabase na **UE**: Auth, PostgreSQL com RLS, Storage, Edge Functions, pg_cron |
| IA | Azure AI Document Intelligence (OCR) e Azure OpenAI (resumos e briefings), via Edge Functions |
| Email | Brevo (só avisos, sem dados clínicos) |

## Começar

Requisitos: Node 22 (`nvm use`).

```bash
npm install
cp .env.example .env.local   # preencher com o projeto Supabase de DESENVOLVIMENTO
npm run dev                  # http://localhost:5173
```

A página `/estado` mostra o ambiente e se a ligação ao Supabase está a funcionar.

## Scripts

| Comando | O que faz |
|---|---|
| `npm run dev` | Servidor de desenvolvimento |
| `npm run build` | Verifica tipos e gera a build de produção em `dist/` |
| `npm run lint` | ESLint (inclui proibição de `console.log`) |
| `npm run typecheck` | Verificação de tipos TypeScript |
| `npm test` | Testes (Vitest + Testing Library) |
| `npm run format` | Formata o código com Prettier |

## Ambientes

| Ambiente | Onde | Supabase | Dados |
|---|---|---|---|
| Desenvolvimento | `npm run dev` no computador | projeto **clarity-dev** | fictícios |
| Pré-visualização | Vercel, um link por pull request | projeto **clarity-dev** | fictícios |
| Produção | Vercel, ramo `main` | projeto **clarity-prod** | fictícios até à avaliação de impacto |

O plano gratuito da Supabase permite dois projetos ativos, que chegam para `clarity-dev` e `clarity-prod`. Ambos devem ser criados numa **região da UE**.

## Configuração inicial (uma vez, feita por um elemento da equipa)

1. **GitHub:** criar o repositório, fazer push deste código para `main` e proteger o ramo `main` (Settings → Branches): pull request obrigatório, 1 aprovação e o check **CI / Lint, tipos, testes e build** a passar.
2. **Supabase:** criar `clarity-dev` e `clarity-prod` numa região da UE. Em cada um, copiar o **Project URL** e a **Publishable key** (Connect ou Project Settings → API Keys).
3. **Vercel:** *Add New → Project*, importar o repositório do GitHub (deteta Vite sozinho). Em *Settings → Environment Variables*:
   - **Production:** `VITE_SUPABASE_URL` e `VITE_SUPABASE_PUBLISHABLE_KEY` do `clarity-prod`, `VITE_APP_ENV=production`
   - **Preview:** os mesmos nomes com os valores do `clarity-dev`, `VITE_APP_ENV=preview`
   - Ativar *Deployment Protection* nas pré-visualizações.
4. **Supabase Auth:** em cada projeto, em *Authentication → URL Configuration*, pôr o domínio da Vercel como *Site URL* e acrescentar `http://localhost:5173` e o padrão dos links de pré-visualização às *Redirect URLs*.

## Como trabalhamos

- Um ramo por tarefa: `feat/importar-notas`, `fix/briefing-hora`, `chore/ci`.
- Pull request para `main` com o template preenchido e revisão de 1 colega.
- O CI tem de passar antes do merge. Cada pull request gera um link de pré-visualização na Vercel.
- Mensagens de commit curtas e no imperativo: `Adiciona ficha do paciente`.

## Segurança desde o primeiro dia

- A chave publishable pode estar no browser; a proteção dos dados vem das regras **RLS**.
- A chave **secret / service_role** nunca entra no frontend nem no repositório (a app recusa-a se for posta por engano).
- O service worker só guarda em cache a "casca" da app; **dados clínicos nunca ficam em cache** no dispositivo.
- Cabeçalhos de segurança e `noindex` configurados em `vercel.json`.
- Permissões do browser: câmara permitida (fotografar notas), microfone bloqueado no MVP (a gravação só entra no produto final).
