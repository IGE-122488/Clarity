/// <reference types="vitest/config" />
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'

// https://vite.dev/config/
const version = process.env.npm_package_version ?? '0.0.0'
const commit = process.env.VERCEL_GIT_COMMIT_SHA?.slice(0, 7)

export default defineConfig({
  define: {
    __APP_VERSION__: JSON.stringify(commit ? `${version} (${commit})` : version),
  },
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: ['favicon.svg', 'icons/*.png'],
      manifest: {
        name: 'Clarity',
        short_name: 'Clarity',
        description: 'Notas, resumos e briefing de sessão para psicólogos.',
        lang: 'pt-PT',
        start_url: '/',
        display: 'standalone',
        background_color: '#F7F7F4',
        theme_color: '#1E3A3D',
        icons: [
          { src: '/icons/icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: '/icons/icon-512.png', sizes: '512x512', type: 'image/png' },
          { src: '/icons/icon-512-maskable.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
        ],
      },
      workbox: {
        // Só a "casca" da app (HTML, JS, CSS, ícones) fica em cache.
        // Dados clínicos (Supabase, IA) NUNCA são guardados em cache no dispositivo.
        globPatterns: ['**/*.{js,css,html,svg,png,woff2}'],
        runtimeCaching: [],
        navigateFallbackDenylist: [/^\/api\//],
      },
    }),
  ],
  test: {
    environment: 'jsdom',
    globals: true,
    setupFiles: ['./src/test/setup.ts'],
    css: false,
  },
})
