## O que muda

<!-- Descrição curta e a issue/tarefa do Jira a que corresponde -->

## Como testar

<!-- Passos para quem faz a revisão -->

## Checklist

- [ ] Só usei **dados fictícios** (nenhuma nota ou nome real de pacientes)
- [ ] Nenhuma chave secreta no código nem em `.env` com commit
- [ ] `npm run lint`, `npm run typecheck`, `npm test` e `npm run build` passam
- [ ] Não há `console.log` com dados de pacientes
- [ ] Se mexe na base de dados: tem migração e regras RLS testadas
