import { createBrowserRouter, RouterProvider } from 'react-router'
import { Layout } from './components/Layout'
import { Inicio } from './pages/Inicio'
import { Estado } from './pages/Estado'
import { NaoEncontrado } from './pages/NaoEncontrado'

export const routes = [
  {
    element: <Layout />,
    children: [
      { path: '/', element: <Inicio /> },
      { path: '/estado', element: <Estado /> },
      { path: '*', element: <NaoEncontrado /> },
    ],
  },
]

const router = createBrowserRouter(routes)

export default function App() {
  return <RouterProvider router={router} />
}
