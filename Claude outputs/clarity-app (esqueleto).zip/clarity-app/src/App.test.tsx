import { render, screen } from '@testing-library/react'
import { createMemoryRouter, RouterProvider } from 'react-router'
import { describe, expect, it, vi } from 'vitest'
import { routes } from './App'

vi.mock('./lib/supabase', () => ({
  appEnv: 'development',
  supabaseUrl: 'https://exemplo.supabase.co',
  supabase: {},
}))


function renderAt(path: string) {
  const router = createMemoryRouter(routes, { initialEntries: [path] })
  return render(<RouterProvider router={router} />)
}

describe('App', () => {
  it('mostra o início com o aviso de dados fictícios', () => {
    renderAt('/')
    expect(screen.getByRole('heading', { name: 'Clarity' })).toBeInTheDocument()
    expect(screen.getByText(/só usamos dados fictícios/)).toBeInTheDocument()
    expect(screen.getByText(/Desenvolvimento · dados fictícios/)).toBeInTheDocument()
  })

  it('mostra a página 404 em pt-PT', () => {
    renderAt('/nao-existe')
    expect(screen.getByRole('heading', { name: 'Página não encontrada' })).toBeInTheDocument()
  })
})
