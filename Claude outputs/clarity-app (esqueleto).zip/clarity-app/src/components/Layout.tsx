import { NavLink, Outlet } from 'react-router'
import { Logo } from './Logo'
import { appEnv } from '../lib/supabase'

export function Layout() {
  return (
    <div className="app">
      <header className="topbar">
        <NavLink to="/" aria-label="Clarity — início">
          <Logo />
        </NavLink>
        <nav aria-label="Navegação principal">
          <NavLink to="/" end>
            Início
          </NavLink>
          <NavLink to="/estado">Estado</NavLink>
        </nav>
        {appEnv !== 'production' && (
          <span className="env-badge" title="Ambiente de testes: apenas dados fictícios">
            {appEnv === 'preview' ? 'Pré-visualização' : 'Desenvolvimento'} · dados fictícios
          </span>
        )}
      </header>
      <main className="content">
        <Outlet />
      </main>
    </div>
  )
}
