import { useEffect, useState } from 'react'
import { appEnv, supabaseUrl } from '../lib/supabase'
import { checkSupabase, type HealthStatus } from '../lib/health'
import { readEnv } from '../lib/env'

export function Estado() {
  const [status, setStatus] = useState<HealthStatus>('a verificar')

  useEffect(() => {
    let active = true
    const { supabasePublishableKey } = readEnv()
    checkSupabase(supabaseUrl, supabasePublishableKey).then((s) => {
      if (active) setStatus(s)
    })
    return () => {
      active = false
    }
  }, [])

  return (
    <section>
      <h1>Estado do sistema</h1>
      <dl className="status">
        <dt>Ambiente</dt>
        <dd>{appEnv}</dd>
        <dt>Versão</dt>
        <dd>{__APP_VERSION__}</dd>
        <dt>Supabase</dt>
        <dd data-status={status}>{status}</dd>
      </dl>
    </section>
  )
}
