export function Inicio() {
  return (
    <section>
      <h1>Clarity</h1>
      <p className="lead">
        Esqueleto da web app. Os ecrãs do MVP (pacientes, importar notas, resumo e briefing)
        entram nos próximos passos.
      </p>
      <p className="notice">
        Regra do projeto: até existir a avaliação de impacto (RGPD), só usamos dados fictícios.
        Nenhuma nota real de pacientes entra nesta app.
      </p>
    </section>
  )
}
