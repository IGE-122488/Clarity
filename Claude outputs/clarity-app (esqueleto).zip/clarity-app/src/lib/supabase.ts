import { createClient } from '@supabase/supabase-js'
import { readEnv } from './env'

const env = readEnv()

// Cliente único da app. Usa a chave publishable: o que cada psicólogo pode ver
// é decidido pelas regras RLS na base de dados, não por esconder a chave.
export const supabase = createClient(env.supabaseUrl, env.supabasePublishableKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
})

export const appEnv = env.appEnv
export const supabaseUrl = env.supabaseUrl
