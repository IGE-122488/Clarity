import { describe, expect, it } from 'vitest'
import { readEnv } from './env'

const ok = {
  VITE_SUPABASE_URL: 'https://exemplo.supabase.co',
  VITE_SUPABASE_PUBLISHABLE_KEY: 'sb_publishable_teste',
}

describe('readEnv', () => {
  it('lê as variáveis e usa development por omissão', () => {
    expect(readEnv(ok)).toEqual({
      supabaseUrl: 'https://exemplo.supabase.co',
      supabasePublishableKey: 'sb_publishable_teste',
      appEnv: 'development',
    })
  })

  it('falha com mensagem clara se faltar uma variável', () => {
    expect(() => readEnv({ VITE_SUPABASE_URL: ok.VITE_SUPABASE_URL })).toThrow(
      /VITE_SUPABASE_PUBLISHABLE_KEY/,
    )
  })

  it('recusa uma chave secreta no browser', () => {
    expect(() => readEnv({ ...ok, VITE_SUPABASE_PUBLISHABLE_KEY: 'sb_secret_abc' })).toThrow(
      /chave secreta/,
    )
  })

  it('recusa um ambiente desconhecido', () => {
    expect(() => readEnv({ ...ok, VITE_APP_ENV: 'teste' })).toThrow(/VITE_APP_ENV/)
  })
})
