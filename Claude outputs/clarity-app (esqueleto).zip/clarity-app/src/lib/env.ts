// Lê e valida as variáveis de ambiente públicas (VITE_*).
// Falha cedo e com uma mensagem clara se faltar alguma, em vez de a app falhar mais tarde.

export type AppEnv = 'development' | 'preview' | 'production'

export interface Env {
  supabaseUrl: string
  supabasePublishableKey: string
  appEnv: AppEnv
}

const APP_ENVS: readonly string[] = ['development', 'preview', 'production']

function str(value: unknown): string | undefined {
  return typeof value === 'string' && value.trim() !== '' ? value.trim() : undefined
}

export function readEnv(source: Record<string, unknown> = import.meta.env): Env {
  const supabaseUrl = str(source.VITE_SUPABASE_URL)
  const supabasePublishableKey = str(source.VITE_SUPABASE_PUBLISHABLE_KEY)
  const appEnv = str(source.VITE_APP_ENV) ?? 'development'

  if (!supabaseUrl || !supabasePublishableKey) {
    const missing = [
      !supabaseUrl && 'VITE_SUPABASE_URL',
      !supabasePublishableKey && 'VITE_SUPABASE_PUBLISHABLE_KEY',
    ].filter(Boolean)
    throw new Error(
      `Faltam variáveis de ambiente: ${missing.join(', ')}. Copiem .env.example para .env.local e preencham-nas.`,
    )
  }

  if (!APP_ENVS.includes(appEnv)) {
    throw new Error(`VITE_APP_ENV inválido: "${appEnv}". Use development, preview ou production.`)
  }

  // Proteção extra: a secret key / service_role nunca pode chegar ao browser.
  if (supabasePublishableKey.startsWith('sb_secret_') || supabasePublishableKey.includes('service_role')) {
    throw new Error(
      'VITE_SUPABASE_PUBLISHABLE_KEY parece ser uma chave secreta. Usem a chave publishable.',
    )
  }

  return { supabaseUrl, supabasePublishableKey, appEnv: appEnv as AppEnv }
}
