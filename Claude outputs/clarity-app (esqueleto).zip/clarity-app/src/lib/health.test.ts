import { describe, expect, it, vi } from 'vitest'
import { checkSupabase } from './health'

describe('checkSupabase', () => {
  it('devolve "ligado" quando o Supabase responde', async () => {
    const fetcher = vi.fn().mockResolvedValue({ ok: true })
    await expect(checkSupabase('https://x.supabase.co', 'k', fetcher)).resolves.toBe('ligado')
    expect(fetcher).toHaveBeenCalledWith('https://x.supabase.co/auth/v1/health', {
      headers: { apikey: 'k' },
    })
  })

  it('devolve "sem ligação" quando há erro de rede', async () => {
    const fetcher = vi.fn().mockRejectedValue(new Error('offline'))
    await expect(checkSupabase('https://x.supabase.co', 'k', fetcher)).resolves.toBe('sem ligação')
  })
})
