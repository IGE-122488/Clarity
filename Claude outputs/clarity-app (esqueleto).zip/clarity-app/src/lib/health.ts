// Verifica se o projeto Supabase responde. Não lê nem escreve dados.
export type HealthStatus = 'a verificar' | 'ligado' | 'sem ligação'

export async function checkSupabase(
  url: string,
  key: string,
  fetcher: typeof fetch = fetch,
): Promise<Exclude<HealthStatus, 'a verificar'>> {
  try {
    const res = await fetcher(`${url}/auth/v1/health`, { headers: { apikey: key } })
    return res.ok ? 'ligado' : 'sem ligação'
  } catch {
    return 'sem ligação'
  }
}
